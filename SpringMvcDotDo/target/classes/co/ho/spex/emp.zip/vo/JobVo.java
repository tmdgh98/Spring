package co.ho.spex.emp.vo;

import lombok.Data;

@Data
public class JobVo {
	private String jobId;
	private String jobTitle;
	private String minSalary;
	private String maxSalary;
	
}
