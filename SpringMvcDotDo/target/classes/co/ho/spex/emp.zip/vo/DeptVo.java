package co.ho.spex.emp.vo;

import lombok.Data;

@Data
public class DeptVo {
	private String departmentId;
	private String departmentName;
	private String managerId;
	private String locationId;
	private String orderColumn;
	
}
