package co.ho.spex.emp.vo;

import lombok.Data;

@Data
public class DeptVo2 {
	private String department_id;
	private String department_name;
	private String manager_id;
	private String location_id;
}
